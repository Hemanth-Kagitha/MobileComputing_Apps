//
//  ViewController.swift
//  HelloApp
//
//  Created by Kagitha,Hemanth Sai on 8/29/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func submitBtnClicked(_ sender: Any) {
        //Read input from text field and
        //assign it to variable
        var input = inputOL.text!
        
        //Display or print the input concatenated with a greeting(String interpolation)
        outputOL.text=("Hello, \(input)!")
    }
}

