//
//  ViewController.swift
//  AnimationsDemo
//
//  Created by Kagitha,Hemanth Sai on 10/24/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    @IBOutlet weak var HappyOL: UIButton!
    
    @IBOutlet weak var SadOL: UIButton!
    
    @IBOutlet weak var AngryOL: UIButton!
    
    @IBOutlet weak var ShakeItOL: UIButton!
    
    @IBOutlet weak var DisplayOL: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        
        //Move imageView outside of screen
        imageViewOL.frame.origin.x = view.frame.maxY
        
        //also all components as well.
        HappyOL.frame.origin.x = view.frame.width
        
        SadOL.frame.origin.x = view.frame.width
        
        AngryOL.frame.origin.x = view.frame.width
        
        ShakeItOL.frame.origin.x = view.frame.width
        
            
    }
    
    
    @IBAction func HappyBtnClicked(_ sender: Any) {
        UpdateAndAnimate("happy")
    }
    
    @IBAction func SadBtnClicked(_ sender: Any) {
        UpdateAndAnimate("sad")
    }
    
    
    @IBAction func AngryBtnClicked(_ sender: Any) {
        UpdateAndAnimate("angry")
    }
    
    
    @IBAction func ShakeItBtnClicked(_ sender: Any) {
        var width = imageViewOL.frame.width
        width += 40
        
        var height = imageViewOL.frame.height
        height += 40
        
        var x = imageViewOL.frame.origin.x - 20
        var y = imageViewOL.frame.origin.y - 20
        
        //create a rectangle object with larger frame
        var largeFrame = CGRect(x: x, y: y, width: width, height: height)
        
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {
            self.imageViewOL.frame = largeFrame
        }
        )
        
        
    }
    
    
    @IBAction func DisplayBtnClicked(_ sender: Any) {
        UIView.animate(withDuration: 1, animations: {
            //Moving all components to center
            self.imageViewOL.center.x = self.view.center.x
            self.HappyOL.center.x = self.view.center.x
            self.SadOL.center.x = self.view.center.x
            self.AngryOL.center.x = self.view.center.x
            self.ShakeItOL.center.x = self.view.center.x
            
        })
        //Disable the Display Button
        DisplayOL.isEnabled = false
    }
    
    func UpdateAndAnimate(_ imageName: String) {
        
        //Make the current image as opaque(alpha should be zero).
        UIView.animate(withDuration: 1, animations: {self.imageViewOL.alpha = 0})
        
        //and Assign new image with animation and makeit transparent(alpha should be 1).
        UIView.animate(withDuration: 1,delay: 0.005, animations: {self.imageViewOL.alpha = 1
            self.imageViewOL.image = UIImage(named: imageName)
        })
    }

}

