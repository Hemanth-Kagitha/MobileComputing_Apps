//
//  ViewController.swift
//  Kagitha_WordGuess
//
//  Created by Hemanth Sai Kagitha on 10/16/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBOutlet weak var playAgainButtonPressed: UIButton!
    
    @IBOutlet weak var displayImage: UIImageView!
    
    var words = [["CAR", "Automobile"],["Sun","Morning Star"],["FISH", "Aquatic animal"],["BICYCLE", "Two-wheeled transport"],["GUITAR", "Musical instrument with strings"]]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func guessLetterButtonPressed(_ sender: Any) {
    }
    
    
    @IBAction func playAgainButtonPressed(_ sender: Any) {
    }
    


}

