//
//  ViewController.swift
//  VowelTester
//
//  Created by Kagitha,Hemanth Sai on 8/31/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func SubmitBtnClicked(_ sender: Any) {
        //Read input text and assign to variable
        var input = inputOL.text!
        
        //check if text is having vowels or not
        if(input.contains("a")) {
            outputOL.text = "The \(input) has vowels!"
        }
        else if(input.contains("e")) {
            outputOL.text = "The \(input) has vowels!"
        }
        else if(input.contains("i")) {
            outputOL.text = "The \(input) has vowels!"
        }
        else if(input.contains("o")) {
            outputOL.text = "The \(input) has vowels!"
        }
        else if(input.contains("u")) {
            outputOL.text = "The \(input) has vowels!"
        }
        
        
        //if text has a, e, i, o, u print  "original text" has vowels
        else {
            outputOL.text = "The \(input) has no vowels!"
        }
        //else, the original text has no vowels
        
    }
    
}

