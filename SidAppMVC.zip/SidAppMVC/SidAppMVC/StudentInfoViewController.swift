//
//  StudentInfoViewController.swift
//  SidAppMVC
//
//  Created by Kagitha,Hemanth Sai on 11/7/23.
//

import UIKit

class StudentInfoViewController: UIViewController {
    
    
    @IBOutlet weak var nameOL: UILabel!
    
    @IBOutlet weak var sidOL: UILabel!
    
    @IBOutlet weak var emailOL: UILabel!
    
    
    @IBOutlet weak var courseOL: UIButton!
    
    //variable created to hold the Student object we recieve from the LoginController
    var studentObj = Student()
    
    var guestUser:Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if guestUser {
            //if the user is guest we will hide all the outlets and display 'Guest User'
            emailOL.isHidden = true
            nameOL.text = "Name: Guest User"
            sidOL.isHidden = true
            courseOL.isHidden = true
            
        }else{
            
            //If the student is found, then we assign the values of the studentObj to the outelts
            sidOL.text = "SID: " + studentObj.sid
            emailOL.text = "Email: " + studentObj.email
            nameOL.text = "Name: " + studentObj.name
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        
        //We need to view courses of the logged in student in CourseViewController,
        // So we pass the courses from the 'studentObj' variable
        if transition == "courseSegue" {
            let destination = segue.destination as! CourseViewController
            
            //we will assign the courses to 'courseArray' in the CourseViewController
            destination.coursesArray = studentObj.courses
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
