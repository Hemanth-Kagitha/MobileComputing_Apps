//
//  ViewController.swift
//  Kagitha_Exam01
//
//  Created by Kagitha,Hemanth Sai on 10/5/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameOL: UITextField!
    
    
    @IBOutlet weak var roomTypeOL: UITextField!
    
    @IBOutlet weak var membershipOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    @IBOutlet weak var imagedisplay: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func calculatePriceBtn(_ sender: Any) {
        
        imagedisplay.isHidden = false
        
        var name = nameOL.text
        var roomtype = roomTypeOL.text
        var membership = membershipOL.text
        var singleRoomtypePrice = Double(74.99)
        var doubleRoomtypePrice = Double(84.99)
        var tax = Double(16.75)
        if (roomtype == "Single-Bed") || (roomtype == "single-bed") {
            if (membership == "Yes") || (membership == "yes"){
                var roomtypePrice = Double(74.99)
                var discountedPrice = roomtypePrice - (roomtypePrice * (5/100))
                var totalPrice = String(format: "%.2f", discountedPrice + (roomtypePrice * (16.75/100)))
                outputOL.text = "Dear \(name!) You have made  a reservation at Bearcat Motel for a \(roomtype!) at a price of  $\(totalPrice) including tax."
                imagedisplay.image = UIImage(named: "Single_Img")
                
            }
            else if(membership == "No") || (membership == "no") {
                imagedisplay.image = UIImage(named: "Single_Img")
                var totalprice = singleRoomtypePrice + (singleRoomtypePrice * (tax/100))
                outputOL.text = "Dear \(name!) You have made  a reservation at Bearcat Motel for a \(roomtype!) at a price of  $\(totalprice) including tax."
            }
        }
        else if (roomtype == "Double-Bed") || (roomtype == "double-bed") {
            
            if (membership == "Yes") || (membership == "yes") {
                var discountprice = doubleRoomtypePrice - (doubleRoomtypePrice * (5/100))
                var totalprice = discountprice + (doubleRoomtypePrice * (16.75/100))
                imagedisplay.image = UIImage(named: "Double_Img")
                outputOL.text = "Dear \(name!) You have made  a reservation at Bearcat Motel for a \(roomtype!) at a price of  $\(totalprice) including tax."
                
            }
            else if (membership == "No") || (membership == "no") {
                imagedisplay.image = UIImage(named: "Double_Img")
                var totalprice = doubleRoomtypePrice + (doubleRoomtypePrice * (tax/100))
                outputOL.text = "Dear \(name!) You have made  a reservation at Bearcat Motel for a \(roomtype!) at a price of  $\(totalprice) including tax."
            }
            
        }
        else {
            outputOL.text = "No room is available withyour preference"
        }
        
    }
    
    
    
    
    
    @IBAction func resetBtnClicked(_ sender: Any) {
        outputOL.text = ""
        nameOL.text = ""
        roomTypeOL.text = ""
        membershipOL.text = ""
        imagedisplay.isHidden = true
    
        
        
    }
    


}

