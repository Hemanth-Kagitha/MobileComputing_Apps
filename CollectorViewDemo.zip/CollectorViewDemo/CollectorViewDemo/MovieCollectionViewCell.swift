//
//  MovieCollectionViewCell.swift
//  CollectorViewDemo
//
//  Created by Kagitha,Hemanth Sai on 11/16/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    //assign image to movie image outlet
    func assignMovie(with movie:Movie) {
        imageViewOL.image = movie.image
        
    }
    
    
}
