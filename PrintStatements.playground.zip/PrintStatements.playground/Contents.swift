import UIKit

var greeting = "Hello, playground"
print(greeting)

print("Hii",10,12.25,"😎")

var progLang = "Swift"
print("My fav programming language is \(progLang)")
print("My fav programming language is : "+progLang)


var age = 22
print("Iam \(age) years old and in another \(age) years, I will be \(age * 2)")

print()
print("""
      Hello!!
      Welcome to,
      My world
      """)
print()
print("Hello ,\rWelcome to Mobile Computing class")

print()
let msg : String = "Hello!!"
print(msg,"One and All")

print()
let num = "-999"
print(num, "is negative")

//var num = 000
print(num)

print()
print("Welcome to Swift programming");
print("Fall 2023")
print("************")
print("Welcome to Swift programming", terminator : " - ")
print("Fall 2023")

print()
print("The List of numbers are : ")
print(1,3,5,7,9,11)
print("The new pattern is")
print(1,3,5,7,9,11, separator: "-")
