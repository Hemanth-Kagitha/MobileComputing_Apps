//
//  ViewController.swift
//  Practise_Exam_Table
//
//  Created by Kagitha,Hemanth Sai on 11/28/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return words.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //1.create the cell
        var cell = tableViewOL.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        
        //2.populate the cell
        cell.textLabel?.text = words[indexPath.row][0]
        
        //3.return the cell
        return cell
    }
    
    
    
    
    
    var words = [
    [ "Benevolent🤗", "Well-meaning and kindly"],
    ["Courage👮🏼‍♀️","The ability to do something that frieghtens one"],
    ["Genuine🌻","Truly what someting is said to be authentic"],
    ["Joy😊","A feeling of great pleasure and Happiness."]]

    @IBOutlet weak var tableViewOL: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableViewOL.delegate = self
        tableViewOL.dataSource = self

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let transition = segue.identifier
        
        if(transition == "wordSegue") {
            let destination = segue.destination as! MeaningViewController
            
            destination.words = words[(tableViewOL.indexPathForSelectedRow?.row)!]
        }
    }


}

