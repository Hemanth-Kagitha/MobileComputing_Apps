//
//  MeaningViewController.swift
//  Practise_Exam_Table
//
//  Created by Kagitha,Hemanth Sai on 11/28/23.
//

import UIKit

class MeaningViewController: UIViewController {
    
    
    @IBOutlet weak var wordDescriptionOL: UILabel!
    
    
    @IBOutlet weak var meanigDescriptionOL: UILabel!
    
    
    var words: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        print(words)
        wordDescriptionOL.text! += words[0]
        
        meanigDescriptionOL.text! += words[1]
        




    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
