//
//  ViewController.swift
//  GreaterBetween2
//
//  Created by Kagitha,Hemanth Sai on 8/31/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstNum: UITextField!
    
    @IBOutlet weak var secondNum: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func submitBtnClicked(_ sender: Any) {
        
        var f = Int(firstNum.text!)
        
        var s = Int(secondNum.text!)
        
        
        
        if(f! > s!) {
            outputOL.text = "\(f)! is greatest"
        }
        else {
            outputOL.text = "\(s)! is greatest!"
        }
    }
}

