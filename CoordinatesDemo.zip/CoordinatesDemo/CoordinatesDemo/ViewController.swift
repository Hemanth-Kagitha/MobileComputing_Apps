//
//  ViewController.swift
//  CoordinatesDemo
//
//  Created by Kagitha,Hemanth Sai on 10/17/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageViewOL: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let minX = imageViewOL.frame.minX
        let minY = imageViewOL.frame.minY
        
        print(minX,",",minY)
        
        let maxX = imageViewOL.frame.maxX
        let maxY = imageViewOL.frame.maxY
        print(maxX,",",maxY)
        
        let midX = imageViewOL.frame.midX
        let midY = imageViewOL.frame.midY
        print(midX,",",midY)
        
        //Display image at top left corner
        imageViewOL.frame.origin.x = 0
        imageViewOL.frame.origin.y = 0
        
        //Display image at top right corner
        imageViewOL.frame.origin.x = 293
        imageViewOL.frame.origin.y = 0
        
        //Display image at bottom right corner
        imageViewOL.frame.origin.x = 293
        imageViewOL.frame.origin.y = 752
        
        //Display image at bottom left corner
        imageViewOL.frame.origin.x = 0
        imageViewOL.frame.origin.y = 752
        
        //Display at center of view
        //(393/2)-50, (752/2)-50
        imageViewOL.frame.origin.x = 146
        imageViewOL.frame.origin.y = 376
        
        
        imageViewOL.frame.origin.x = 244
        imageViewOL.frame.origin.y = 97
        
        
    }


}

