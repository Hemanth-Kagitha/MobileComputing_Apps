import UIKit

var greeting = "Hello, playground"

var mobile = "Nothing"
mobile = "OnePlus+"
print(mobile)

print()
var luckyNum = 48
luckyNum = 3
print(luckyNum)

print()
let pi = "22/7"
print(pi)

print()
var age : Int = 22
age = age * 2
print(age)

print()
var message = "This course is Intresting!!"
print(message)
print("message")

print()
var course1 = "java"
var course2 = "ios"
print(course1,course2)
print(course1,"-",course2)

print()
print(10,20,33)
print(12.5,87.0,"KKK")
