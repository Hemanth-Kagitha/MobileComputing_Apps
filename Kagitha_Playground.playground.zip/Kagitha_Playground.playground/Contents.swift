import UIKit

var greeting = "Hello, playground"
print("Hello class");

print(greeting)
print("I'm Hemanth Sai")
