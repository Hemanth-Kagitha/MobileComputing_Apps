//
//  ViewController.swift
//  FullNameApp
//
//  Created by Kagitha,Hemanth Sai on 8/29/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstNameOL: UITextField!
    
    @IBOutlet weak var lastNameOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func submitBtnClicked(_ sender: Any) {
        var fname = firstNameOL.text!
        var lname = lastNameOL.text!
        
        outputOL.text = ("Hello, \(fname)  \(lname)!🤓")
        
    }
  
    
}

