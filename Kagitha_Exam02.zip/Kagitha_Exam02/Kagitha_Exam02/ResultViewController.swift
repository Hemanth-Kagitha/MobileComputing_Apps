//
//  ResultViewController.swift
//  Kagitha_Exam02
//
//  Created by Kagitha,Hemanth Sai on 11/14/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var displayLoanType: UILabel!
    
    @IBOutlet weak var displayLoanAmount: UILabel!
    
    
    @IBOutlet weak var displayInterestRate: UILabel!
    
    
    @IBOutlet weak var displayCalculatedEMI: UILabel!
    
    
    @IBOutlet weak var displayImage: UIImageView!
    
    var loanType = ""
    var loanAmount = 0.00
    var interestRate = 0.00
    var term = 0.00
    var monthlyEMIPayment = 0.00
    
    var imageName = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //displayWeightOL.text! += weight
        displayLoanType.text! += loanType
        displayLoanAmount.text! += String(loanAmount)
        displayInterestRate.text! += String(interestRate)
        displayCalculatedEMI.text! += String(monthlyEMIPayment)
        
        displayImage.image = UIImage(named: imageName)
    }
    
    func UpdateAndAnimate(_ imageName: String) {
        
        //Make the current image as opaque(alpha should be zero).
        UIView.animate(withDuration: 1, animations: {self.displayImage.alpha = 0})
        
        //and Assign new image with animation and makeit transparent(alpha should be 1).
        UIView.animate(withDuration: 1,delay: 0.005, animations: {self.displayImage.alpha = 1
            self.displayImage.image = UIImage(named: imageName)
        })
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
