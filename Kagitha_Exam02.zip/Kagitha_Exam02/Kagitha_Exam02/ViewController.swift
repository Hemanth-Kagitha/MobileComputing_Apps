//
//  ViewController.swift
//  Kagitha_Exam02
//
//  Created by Kagitha,Hemanth Sai on 11/14/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var loanTypeOL: UITextField!
    
    @IBOutlet weak var loanAmountOL: UITextField!
    
    
    @IBOutlet weak var interestRateOL: UITextField!
    
    
    @IBOutlet weak var termOL: UITextField!
    
    
    
    @IBOutlet weak var calcEMIBtn: UIButton!
    
    @IBOutlet weak var resetBtn: UIButton!
    
    var totalMonths = 0.00
    var monthlyInterestRate = 0.00
    var monthlyEMIPayment = 0.00
    
    var imageName = ""
    
    var calculatedMonthlyEMI = 0
    
    var loanAmount = 0.00
    var interestRate = 0.00
    var term = 0.00
    //var loanAmount = 0.00
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
       
        
        
    }
    

    @IBAction func calculateEMIBtnCLicked(_ sender: Any) {
        
        var loanType = loanTypeOL.text!
        loanAmount = Double(loanAmountOL.text!)!
        interestRate =  Double(interestRateOL.text!)!
        term = Double(termOL.text!)!
        
        totalMonths = (term * 12)
        monthlyInterestRate = (interestRate/12)/100
        
        monthlyEMIPayment = loanAmount * (monthlyInterestRate * pow(1 + monthlyInterestRate,totalMonths)) / (pow(1 + monthlyInterestRate,totalMonths) - 1)
        
        if loanType == "Car" {
            imageName = "Car"
        }
        else if loanType == "Personal" {
            imageName = "Personal"
        }
        else if loanType == "Home" {
            imageName = "Home"
        }
        
    }
    
    @IBAction func resetBtnClicked(_ sender: Any) {
        loanAmountOL.text! = ""
        loanTypeOL.text! = ""
        interestRateOL.text! = ""
        termOL.text! = ""
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //create a variable called transition
        var transition = segue.identifier
        
        if transition == "ResultSegue" {
            var destination = segue.destination as! ResultViewController
            
            destination.loanType = loanTypeOL.text!
            destination.loanAmount = loanAmount
            destination.interestRate = interestRate
            destination.term = term
            
            destination.monthlyEMIPayment = monthlyEMIPayment
            
            destination.imageName = imageName
        }
        
        
    }
    
}

