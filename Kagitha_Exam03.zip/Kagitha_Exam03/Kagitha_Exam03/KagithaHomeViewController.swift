//
//  ViewController.swift
//  Kagitha_Exam03
//
//  Created by Kagitha,Hemanth Sai on 11/30/23.
//

import UIKit

class KagithaHomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource  {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //1.create the cell
        var cell = KagithaTVOL.dequeueReusableCell(withIdentifier: "KagithaCell", for: indexPath)
        
        //2.populate the cell
        cell.textLabel?.text = contacts[indexPath.row][0]
        
        //3.return the cell
        return cell
    }
    
    var contacts = [["Alex Brown","Brown", "660-528-6785"],
    ["Ava Robinson","Robinson","660-528-6884"],
    ["Bob Johnson","Johnson","660-456-9860"],
    ["Hemanth Kagitha","Kagitha","660-528-7614"],
    ["Virat Kohli","Kohli","660-432-7866"],
    ["Michael Johnson","Johnson","660-345-1299"],
    ["Jane Smith","Smith","660-765-6543"],
    ["John Doe","Doe","918-225-6809"],
    ["Pratap Kuchi","Kuchi","543-980-6788"],
    ["Ajay Bandi","Bandi","566-894-0977"],
    ["Renato Pique","Pique","787-999-4322"]]
    

    @IBOutlet weak var KagithaTVOL: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        KagithaTVOL.delegate = self
        KagithaTVOL.dataSource = self
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let transition = segue.identifier
        
        if(transition == "KagithaContactSegue") {
            let destination = segue.destination as! KagithaContactViewController
            
            destination.contacts = contacts[(KagithaTVOL.indexPathForSelectedRow?.row)!]
        }
    }


}

