//
//  KagithaContactViewController.swift
//  Kagitha_Exam03
//
//  Created by Kagitha,Hemanth Sai on 11/30/23.
//

import UIKit

class KagithaContactViewController: UIViewController {
    
    
    
    @IBOutlet weak var initialsOL: UILabel!
    
    
    @IBOutlet weak var phoneNumberOL: UILabel!
    
    var contacts: [String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        var f = contacts[0]
        var fs = f[f.startIndex]
        
        var l = contacts[1]
        var ls = l[l.startIndex]
        
        initialsOL.text! += " \(ls). \(fs)."
        phoneNumberOL.text! += contacts[2]
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
