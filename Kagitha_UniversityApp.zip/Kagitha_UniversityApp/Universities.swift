//
//  Universities.swift
//  Kagitha_UniversityApp
//
//  Created by Hemanth Sai Kagitha on 11/15/23.
//

import Foundation



struct UniversityList {
    var collegeName: String
    var collegeImage: String
    var collegeInfo: String
    var domain: String
    
}
    
    struct Universities {
        
        static let domains = ["Information Technology", "Computer Science", "Data Science and Analytics", "Cyber Security"]
        static var universitiesByDomain: [String: [UniversityList]] = [:]
            
            static func setupData() {
                for domain in domains {
                    let universitiesForDomain = list_Array.filter { $0.domain == domain }
                    universitiesByDomain[domain] = universitiesForDomain
                }
            }
        static let list_Array: [UniversityList] = [
            UniversityList(collegeName: "Northwest Missouri State University", collegeImage: "nwmsu", collegeInfo: "Northwest Missouri State University (NW Missouri) is a public university in Maryville, Missouri. It has an enrollment of about 8,505 students.[4] Founded in 1905 as a teachers college, its campus is based on the design for Forest Park at the 1904 St. Louis World's Fair and is the official Missouri State Arboretum.[5] The school is governed by a state-appointed Board of Regents and headed by President Dr. Lance Tatum.",domain: "Information Technology"),
            UniversityList(collegeName: "University of Central Missouri", collegeImage: "ucm", collegeInfo: "Founded in 1871, the University of Central Missouri is one of the oldest universities in the state. It opened its doors with only 30 students and is now home to more than 10,500 students who represent 47 states and 36 countries. With “Education for Service,” as its motto, UCM has a rich heritage of providing unparalleled student support, exceptional academic programs and valuable learning opportunities, helping students achieve success through affordable access to a high-quality education for the past 150 years.",domain: "Information Technology"),
            UniversityList(collegeName: "George Mason University", collegeImage: "gmu", collegeInfo: "As Virginia’s largest public research university, George Mason University provides a college experience like no other. Mason offers more than 200 undergraduate and graduate degrees and numerous minors and certificate programs to customize your education and meet your career and personal goals. Mason's six-year graduation rate exceeds the national average, with no disparity based on ethnicity or economic status.",domain: "Information Technology"),
            UniversityList(collegeName: "University of Texas at Dallas", collegeImage: "utd", collegeInfo: "UT Dallas is a top public university located in one of the nation’s fastest-growing metropolitan regions. Our seven schools offer more than 140 undergraduate and graduate programs, plus professional certificates and fast-track programs.",domain: "Information Technology"),
            UniversityList(collegeName: "University of South Florida", collegeImage: "usf", collegeInfo: "USF is situated in the vibrant and diverse Tampa Bay region, with campuses in Tampa, St. Petersburg and Sarasota-Manatee. Together, our campuses serve more than 50,000 students pursuing undergraduate, graduate, specialist and professional degrees. Across our 13 colleges, undergraduates choose from more than 200 majors, minors and concentrations, from business and engineering to the arts and USF Health.",domain: "Information Technology"),
            UniversityList(collegeName: "Florida International University", collegeImage: "fiu", collegeInfo: "FIU has positioned itself as one of South Florida's anchor institutions by solving some of the greatest challenges of our time. We are dedicated to enriching the lives of the local and global community. With a student body of more than 56,000, we are among the top 10 largest universities in the nation and have collectively graduated more than 275,000 alumni, 165,000 of whom live and work in South Florida.", domain: "Computer Science"),
            UniversityList(collegeName: "Harward University,Cambridge", collegeImage: "harward", collegeInfo: "Harvard University is a private Ivy League research university in Cambridge, Massachusetts. Founded in 1636 as Harvard College and named for its first benefactor, the Puritan clergyman John Harvard, it is the oldest institution of higher learning in the United States. Its influence, wealth, and rankings have made it one of the most prestigious universities in the world.",domain: "Computer Science"),
            UniversityList(collegeName: "Stanford Unniversity,Stanford", collegeImage: "stanford", collegeInfo: "Stanford University (officially Leland Stanford Junior University)[12][13] is a private research university in Stanford, California. The campus occupies 8,180 acres (3,310 hectares), among the largest in the United States, and enrolls over 17,000 students.[14] Stanford has been considered to be one of the most prestigious universities in the world.",domain: "Computer Science"),
            UniversityList(collegeName: "University of California, Berkeley", collegeImage: "uniofCali", collegeInfo: "The University of California, Berkeley (UC Berkeley, Berkeley, Cal, or California),[11][12] is a public land-grant research university in Berkeley, California. It was established in 1868 as the University of California and is the state's first land-grant university and the founding campus of the University of California system. Berkeley has been regarded to be among the top universities in the world.",domain: "Computer Science"),
            UniversityList(collegeName: "Columbia University, NewYork", collegeImage: "columbiauniv", collegeInfo: "Columbia University, officially titled as Columbia University in the City of New York,[9] is a private Ivy League research university in New York City. Established in 1754 as King's College on the grounds of Trinity Church in Manhattan, it is the oldest institution of higher education in New York and the fifth-oldest in the United States. Columbia was established as a colonial college by royal charter under George II of Great Britain.",domain: "Computer Science"),
            UniversityList(collegeName: "University of Michigan, Ann Arbor", collegeImage: "uom", collegeInfo: "The University of Michigan is a public research university in Ann Arbor, Michigan. Founded in 1817, the university is the oldest and largest in Michigan; it was established twenty years before the territory became a state. It is also a founding member of the Association of American Universities. Since 1871, Michigan has been a coeducational institution. In 2021, it enrolled approximately 32,000 undergraduate students and 18,000 graduate students.",domain: "Data Science and Analytics"),
            UniversityList(collegeName: "Duke University, Durham", collegeImage: "dukeuniv", collegeInfo: "Duke University is a private research university in Durham, North Carolina, United States. Founded by Methodists and Quakers in the present-day city of Trinity in 1838, the school moved to Durham in 1892.[13] In 1924, tobacco and electric power industrialist James Buchanan Duke established The Duke Endowment and the institution changed its name to honor his deceased father, Washington Duke.",domain: "Data Science and Analytics"),
            UniversityList(collegeName: "California Institute of Technology", collegeImage: "ciu", collegeInfo: "The California Institute of Technology (branded as Caltech)[9] is a private research university in Pasadena, California. The university is responsible for many modern scientific advancements and is among a small group of institutes of technology in the United States which are strongly devoted to the instruction of pure and applied sciences.",domain: "Data Science and Analytics"),
            UniversityList(collegeName: "Boston University", collegeImage: "bu", collegeInfo: "Boston University (BU) is a private research university in Boston, Massachusetts. BU was founded in 1839 by a group of Boston Methodists with its original campus in Newbury, Vermont, before being chartered in Boston in 1869. It is a member of the Association of American Universities and the Boston Consortium for Higher Education.",domain: "Data Science and Analytics"),
            UniversityList(collegeName: "Wake Forest University (WFU)", collegeImage: "wfu", collegeInfo: "Wake Forest University (WFU) is a private research university in Winston-Salem, North Carolina, United States. Founded in 1834, the university received its name from its original location in Wake Forest, north of Raleigh, North Carolina. The Reynolda Campus, the university's main campus, has been located north of downtown Winston-Salem since the university moved there in 1956.",domain: "Data Science and Analytics"),
            UniversityList(collegeName: "Yale University", collegeImage: "yu", collegeInfo: "Yale University is a private Ivy League research university in New Haven, Connecticut. Founded in 1701, Yale is the third-oldest institution of higher education in the United States and one of the nine colonial colleges chartered before the American Revolution.",domain: "Cyber Security"),
            UniversityList(collegeName: "Princeton University", collegeImage: "pu", collegeInfo: "Princeton University is a private Ivy League research university in Princeton, New Jersey. Founded in 1746 in Elizabeth as the College of New Jersey, Princeton is the fourth-oldest institution of higher education in the United States and one of the nine colonial colleges chartered before the American Revolution.[8][9][a] The institution moved to Newark in 1747, and then to the current site nine years later.", domain: "Cyber Security"),
            UniversityList(collegeName: "Dartmouth College", collegeImage: "dc", collegeInfo: "Dartmouth College (/ˈdɑːrtməθ/; DART-məth) is a private Ivy League research university in Hanover, New Hampshire. Established in 1769 by Eleazar Wheelock, it is one of the nine colonial colleges chartered before the American Revolution. Although originally established to educate Native Americans in Christian theology and the English way of life, the university primarily trained Congregationalist ministers during its early history before it gradually secularized.", domain: "Cyber Security"),
            UniversityList(collegeName: "The University of Tampa", collegeImage: "ut", collegeInfo: "The University of Tampa is a private university in Tampa, Florida. It is accredited by the Southern Association of Colleges and Schools. UT offers more than 200 programs of study, including 22 master's degrees and a broad variety of majors, minors, pre-professional programs, and certificates.", domain: "Cyber Security"),
            UniversityList(collegeName: "Valparaiso University", collegeImage: "vu", collegeInfo: "Valparaiso University is a private university in Valparaiso, Indiana. It is an independent Lutheran university with five undergraduate colleges and a graduate school. It enrolls nearly 2,900 students and has a 350-acre campus.", domain: "Cyber Security")
            
        ]
        
    }
    
    

