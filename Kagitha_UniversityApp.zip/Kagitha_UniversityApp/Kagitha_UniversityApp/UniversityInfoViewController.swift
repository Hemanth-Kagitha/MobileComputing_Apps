//
//  UniversityInfoViewController.swift
//  Kagitha_UniversityApp
//
//  Created by Hemanth Sai Kagitha on 11/15/23.
//

import UIKit

class UniversityInfoViewController: UIViewController {
    var info = ""
    var selected_image = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        about.text = ""
        
        universityimage.image = UIImage(named: selected_image)
        
        //universityimage.alpha = 0.0
        universityimage.frame.origin.x = view.frame.maxX
        
        
        
       /* UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseIn, animations: {
            self.universityimage.alpha = 1.0
        }, completion: nil)*/
        UIView.animate(withDuration: 1,delay:0.6, animations: {
            self.universityimage.center.x = self.view.center.x
    
        })
    }
       
    
        

    @IBOutlet weak var universityimage: UIImageView!
   
    @IBAction func clickme(_ sender: UIButton) {
        about.text = info
    }
    
    @IBOutlet weak var about: UITextView!
    
    
    
   

}
