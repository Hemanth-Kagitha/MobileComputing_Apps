//
//  ViewController.swift
//  Kagitha_UniversityApp
//
//  Created by Hemanth Sai Kagitha on 11/15/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

